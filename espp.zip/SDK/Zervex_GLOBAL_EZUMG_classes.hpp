#pragma once

// =============================================================================
// PUBG Mobile Global 4.7.0 (4.7.0 -- 64-Bit) SDK
// Copyright (C) 2026 Zervex RIYAZ. All Rights Reserved.
// Developed by: @Zervexcheat RIYAZ (TG: @RIYAZXERO | Channel: @RIYAZ_STUFF)
// GitHub: https://github.com/RIYAZXERO
// Generation Time: Thu Nov 12 22:34:20 2026

// =============================================================================

namespace SDK
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// Class EZUMG.EnhancedButton
// 0x00F0 (0x0208 - 0x0118)
class UEnhancedButton : public UContentWidget
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0118(0x0010) MISSED OFFSET
	struct FScriptMulticastDelegate                    OnPressed;                                                // 0x0128(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnReleased;                                               // 0x0138(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnCancelled;                                              // 0x0148(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnDragStarted;                                            // 0x0158(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnDragMoved;                                              // 0x0168(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnDragEnded;                                              // 0x0178(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnSwipedUp;                                               // 0x0188(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnSwipedDown;                                             // 0x0198(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnSwipedLeft;                                             // 0x01A8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnSwipedRight;                                            // 0x01B8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnTapped;                                                 // 0x01C8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnLongPressed;                                            // 0x01D8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnLongReleased;                                           // 0x01E8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	unsigned char                                      UnknownData01[0x10];                                      // 0x01F8(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.EnhancedButton");
		return pStaticClass;
	}


	float GetCurrentHeldDuration();
	void ForceCancel();
	void ApplyConfig();
};


// Class EZUMG.EnhancedSlider
// 0x0028 (0x04C0 - 0x0498)
class UEnhancedSlider : public USlider
{
public:
	bool                                               bEnableSteppedSliding;                                    // 0x0498(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bOnlyRespondToThumb;                                      // 0x0499(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x049A(0x0002) MISSED OFFSET
	struct FLinearColor                                FilledBarColor;                                           // 0x049C(0x0010) (Edit, BlueprintVisible, IsPlainOldData)
	struct FLinearColor                                UnfilledBarColor;                                         // 0x04AC(0x0010) (Edit, BlueprintVisible, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x04BC(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.EnhancedSlider");
		return pStaticClass;
	}


	void SetUnfilledBarColor(const struct FLinearColor& InValue);
	void SetOnlyRespondToThumb(bool InValue);
	void SetFilledBarColor(const struct FLinearColor& InValue);
	void SetEnableSteppedSliding(bool InValue);
	struct FLinearColor GetUnfilledBarColor();
	bool GetOnlyRespondToThumb();
	struct FLinearColor GetFilledBarColor();
	bool GetEnableSteppedSliding();
};


// Class EZUMG.EzAnimationLibrary
// 0x0000 (0x0028 - 0x0028)
class UEzAnimationLibrary : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.EzAnimationLibrary");
		return pStaticClass;
	}


	static class UWidgetAnimation* DuplicateAnimWithRemap(class UUserWidget* OwningWidget, class UWidgetAnimation* Template, TMap<class UWidget*, class UWidget*> RemapTable);
	static class UWidgetAnimation* DuplicateAnimRebindTrack(class UUserWidget* OwningWidget, class UWidgetAnimation* Template, class UWidget* SourceWidget, class UWidget* TargetWidget);
	static class UWidgetAnimation* DuplicateAnimForWidget(class UUserWidget* OwningWidget, class UWidgetAnimation* Template, class UWidget* TargetWidget);
};


// Class EZUMG.EzFactory
// 0x0000 (0x0028 - 0x0028)
class UEzFactory : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.EzFactory");
		return pStaticClass;
	}


	void SetNum(int NumItems);
	bool RemoveLastItem();
	int GetFactoryItemCount();
	class UWidget* AddItem();
};


// Class EZUMG.EzSelectable
// 0x0000 (0x0028 - 0x0028)
class UEzSelectable : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.EzSelectable");
		return pStaticClass;
	}


	void OnStateRefresh(EEzItemState NewState);
};


// Class EZUMG.EzSelectorSlot
// 0x0000 (0x0028 - 0x0028)
class UEzSelectorSlot : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.EzSelectorSlot");
		return pStaticClass;
	}

};


// Class EZUMG.EzSelector
// 0x0000 (0x0028 - 0x0028)
class UEzSelector : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.EzSelector");
		return pStaticClass;
	}


	void SetSelection(int Index);
	void SetSelectedIndex(int Index);
	void SetItemEnabled(int ItemIndex, bool bEnabled);
	bool IsItemSelected(int ItemIndex);
	bool IsItemEnabled(int ItemIndex);
	void GetSelectedIndices(TArray<int>* OutIndices);
	int GetSelectedIndex();
	int GetNumSelectedItems();
	EEzItemState GetItemState(int ItemIndex);
	int GetHoveredIndex();
	int GetFocusedIndex();
	void ForceSelection(int Index);
	void ClearSelection();
};


// Class EZUMG.HorizontalSelectorSlot
// 0x0010 (0x0078 - 0x0068)
class UHorizontalSelectorSlot : public UHorizontalBoxSlot
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0068(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.HorizontalSelectorSlot");
		return pStaticClass;
	}

};


// Class EZUMG.HorizontalSelector
// 0x0068 (0x0190 - 0x0128)
class UHorizontalSelector : public UHorizontalBox
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0128(0x0010) MISSED OFFSET
	EEzSelectionMode                                   SelectionMode;                                            // 0x0138(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0139(0x0007) MISSED OFFSET
	class UClass*                                      itemType;                                                 // 0x0140(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UHorizontalSelectorSlot*                     DefaultSlotTemplate;                                      // 0x0148(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData)
	TArray<TWeakObjectPtr<class UWidget>>              FactoryCreatedItems;                                      // 0x0150(0x0010) (ExportObject, ZeroConstructor, Transient)
	struct FScriptDelegate                             OnItemSelected;                                           // 0x0160(0x000C) (Edit, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0160(0x0004) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY
	struct FScriptMulticastDelegate                    OnItemStateChanged;                                       // 0x0170(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0180(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.HorizontalSelector");
		return pStaticClass;
	}

};


// Class EZUMG.RadialPanel
// 0x0018 (0x0130 - 0x0118)
class URadialPanel : public UPanelWidget
{
public:
	float                                              SectorPadding;                                            // 0x0118(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ERadialArrangement                                 Arrangement;                                              // 0x011C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x13];                                      // 0x011D(0x0013) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.RadialPanel");
		return pStaticClass;
	}


	void SetStartAngleOffset(float InStartAngleOffset);
	void SetSectorPadding(float InSectorPadding);
	void SetArrangement(ERadialArrangement InArrangement);
	float GetAngleAtPosition(const struct FVector2D& LocalPosition);
};


// Class EZUMG.RadialSlot
// 0x00E8 (0x0128 - 0x0040)
class URadialSlot : public UPanelSlot
{
public:
	TEnumAsByte<enum ESectorSizeRule>                  SectorSizeRule;                                           // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0041(0x0003) MISSED OFFSET
	float                                              SectorSizeValue;                                          // 0x0044(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              InnerRadiusRatio;                                         // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              OuterRadiusRatio;                                         // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoSize;                                                // 0x0050(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0051(0x0007) MISSED OFFSET
	struct FSlateBrush                                 SectorBrush;                                              // 0x0058(0x00B8) (Edit, BlueprintVisible)
	struct FLinearColor                                SectorColorAndOpacity;                                    // 0x0110(0x0010) (Edit, BlueprintVisible, IsPlainOldData)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0120(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.RadialSlot");
		return pStaticClass;
	}


	static class URadialSlot* SlotAsRadialSlot(class UWidget* Widget);
	void SetSectorSizeValue(float Value);
	void SetSectorSizeRule(TEnumAsByte<enum ESectorSizeRule> InRule);
	void SetSectorColorAndOpacity(const struct FLinearColor& InTint);
	void SetSectorBrush(const struct FSlateBrush& InBrush);
	void SetOuterRadiusRatio(float InOuterRadiusRatio);
	void SetInnerRadiusRatio(float InInnerRadiusRatio);
	void SetAutoSize(bool bInAutoSize);
	float GetCenterRadiusRatio();
	float GetCenterAngle();
	float GetArcSize();
};


// Class EZUMG.RadialSelectorSlot
// 0x0010 (0x0138 - 0x0128)
class URadialSelectorSlot : public URadialSlot
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0128(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.RadialSelectorSlot");
		return pStaticClass;
	}

};


// Class EZUMG.RadialSelector
// 0x0058 (0x0188 - 0x0130)
class URadialSelector : public URadialPanel
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0130(0x0010) MISSED OFFSET
	EEzSelectionMode                                   SelectionMode;                                            // 0x0140(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0141(0x0007) MISSED OFFSET
	class UClass*                                      itemType;                                                 // 0x0148(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class URadialSelectorSlot*                         DefaultSlotTemplate;                                      // 0x0150(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData)
	TArray<TWeakObjectPtr<class UWidget>>              FactoryCreatedItems;                                      // 0x0158(0x0010) (ExportObject, ZeroConstructor, Transient)
	struct FScriptDelegate                             OnItemSelected;                                           // 0x0168(0x000C) (Edit, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0168(0x0004) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY
	struct FScriptMulticastDelegate                    OnItemStateChanged;                                       // 0x0178(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.RadialSelector");
		return pStaticClass;
	}


	int GetChildIndexByVector(const struct FVector2D& CenterOffset, float DeadzoneLength);
	int GetChildIndexByAngle(float Angle);
	int GetChildIndexAtPosition(const struct FVector2D& LocalPosition);
};


// Class EZUMG.VerticalSelectorSlot
// 0x0010 (0x0078 - 0x0068)
class UVerticalSelectorSlot : public UVerticalBoxSlot
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0068(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.VerticalSelectorSlot");
		return pStaticClass;
	}

};


// Class EZUMG.VerticalSelector
// 0x0068 (0x0190 - 0x0128)
class UVerticalSelector : public UVerticalBox
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0128(0x0010) MISSED OFFSET
	EEzSelectionMode                                   SelectionMode;                                            // 0x0138(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0139(0x0007) MISSED OFFSET
	class UClass*                                      itemType;                                                 // 0x0140(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UVerticalSelectorSlot*                       DefaultSlotTemplate;                                      // 0x0148(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData)
	TArray<TWeakObjectPtr<class UWidget>>              FactoryCreatedItems;                                      // 0x0150(0x0010) (ExportObject, ZeroConstructor, Transient)
	struct FScriptDelegate                             OnItemSelected;                                           // 0x0160(0x000C) (Edit, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0160(0x0004) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY
	struct FScriptMulticastDelegate                    OnItemStateChanged;                                       // 0x0170(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0180(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.VerticalSelector");
		return pStaticClass;
	}


	int GetChildIndexAtPosition(const struct FVector2D& LocalPosition);
};


// Class EZUMG.WrapSelectorSlot
// 0x0010 (0x0078 - 0x0068)
class UWrapSelectorSlot : public UWrapBoxSlot
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0068(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.WrapSelectorSlot");
		return pStaticClass;
	}

};


// Class EZUMG.WrapSelector
// 0x0068 (0x01A0 - 0x0138)
class UWrapSelector : public UWrapBox
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0138(0x0010) MISSED OFFSET
	EEzSelectionMode                                   SelectionMode;                                            // 0x0148(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0149(0x0007) MISSED OFFSET
	class UClass*                                      itemType;                                                 // 0x0150(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UWrapSelectorSlot*                           DefaultSlotTemplate;                                      // 0x0158(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData)
	TArray<TWeakObjectPtr<class UWidget>>              FactoryCreatedItems;                                      // 0x0160(0x0010) (ExportObject, ZeroConstructor, Transient)
	struct FScriptDelegate                             OnItemSelected;                                           // 0x0170(0x000C) (Edit, ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0170(0x0004) FIX WRONG TYPE SIZE OF PREVIOUS PROPERTY
	struct FScriptMulticastDelegate                    OnItemStateChanged;                                       // 0x0180(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0190(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class EZUMG.WrapSelector");
		return pStaticClass;
	}

};


}

